﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scontro_fra_veicoli
{
    interface IConfronta
    {
        void Scontro();
        void Stampa();
    }
}
